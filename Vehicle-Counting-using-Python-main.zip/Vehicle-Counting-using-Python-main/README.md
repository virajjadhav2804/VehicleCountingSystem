# Vehicle-Counting-using-Python
In this article, I have code a vehicle counting and detection system.
